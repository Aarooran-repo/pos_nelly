<?php

class Combo_item extends ActiveRecord\Model {

   public static $table_name = 'combo_items';

}
