<?php

class Posale extends ActiveRecord\Model {

}
