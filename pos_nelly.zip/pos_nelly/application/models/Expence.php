<?php

class Expence extends ActiveRecord\Model {

}
