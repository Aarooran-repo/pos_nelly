<?php

class Warehouse extends ActiveRecord\Model {

}
